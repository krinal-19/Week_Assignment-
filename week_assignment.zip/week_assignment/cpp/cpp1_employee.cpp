
#include <iostream>
using namespace std;

class employee

{
    double salary;
    int hours;
    
    public:
    employee(){}
    void getinfo()
    {
        cout<<"enter the salary:";
        cin>>salary;
        cout<<"\nenter the no of hours:";
        cin>>hours;
        
    }
    void addsal()
    {
        
        if(salary<500)
        {
            salary+=10;
        }
        
        
    }
    void addwork()
    {
      if(hours>6)
      {
          salary+=5;
      }
    }
    void display()
    {
        cout<<salary;
    }
    
};

int main()
{
    int num;
    cout<<"enter the number of employee:";
    cin>>num;
    employee* emp=new employee[num];
    for(int i=0;i<num;i++)
{
    emp[i].getinfo();
    emp[i].addsal();
    emp[i].addwork();
    
}
for(int i=0;i<num;i++)
{
    cout<<"\n the final salary of employee "<<i<<"is";
    emp[i].display();
}
return 0;
}

