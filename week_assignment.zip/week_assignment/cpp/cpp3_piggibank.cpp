#include<iostream>
using namespace std;

class addamount
{
    int amount;
    public:
    addamount()
    {
        amount=50;
    }
    addamount(int a)
    {
        amount=50;
        amount=a+amount;

    }
    void display()
    {
        cout<<amount<<endl;

    }
};

int main()
{
    addamount a1;
    int am;
    cout<<"current amount is: ";
    a1.display();
    cout<<"enter the addamount:";
    cin>>am;
    addamount a2(am);
    cout<<"after add amount total amount is: ";
    a2.display();
    return 0;
}
